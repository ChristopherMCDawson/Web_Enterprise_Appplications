/*Christopher Decarie-Dawson
 *date:2023-07-24
 *Student#:040718315
 *JAXRConfiguration.java
 *###################################
 *Defines the store types of and calls to PasswordHash.class.
 */
package cst8218.dec0058.appuser;

import javax.annotation.security.DeclareRoles;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("resources")
@DatabaseIdentityStoreDefinition(
   dataSourceLookup = "${'java:comp/DefaultDataSource'}",
   callerQuery = "#{'select password from app.appuser where userid = ?'}",
   groupsQuery = "select groupname from app.appuser where userid = ?",
   hashAlgorithm = PasswordHash.class,
   priority = 10
)
//@BasicAuthenticationMechanismDefinition(realmName = "myRealm")
//@DeclareRoles({"Admin"})
//@ApplicationScoped
@Named
@ApplicationScoped

public class JAXRSConfiguration extends Application {
    
}