/*Christopher Decarie-Dawson
 *date:2023-07-24
 *Student#:040718315
 *AppUser.java
 *###################################
 * holds entity values , validations and getter/setters. 
 * Also holds the passwords entry and convertion to hashpassword.
 */
package cst8218.deca0058.appuser.entity;

import java.io.Serializable;
import java.util.HashMap;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.CDI;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Christopher Decarie-Dawson
 */
@Entity

public class AppUser implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "userid")
    @NotNull
    private String userid;
    
    @Column(name = "password")  
    @NotNull
    private String password;
    
    @Column(name = "groupname") 
    @NotNull
    private String groupname;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AppUser)) {
            return false;
        }
        AppUser other = (AppUser) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

   

    /**
     * @return the userid
     */
    public String getUserid() {
        return userid;
    }

    /**
     * @param userid the userid to set
     */
    public void setUserid(String userid) {
        this.userid = userid;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return "";
    }

    /**
     * @param password the password to set
     */
public void setPassword(String password) {
    if (password.length() == 0) {
        return;
    }
    // Initialize a PasswordHash object which will generate password hashes
    Instance<? extends PasswordHash> instance = CDI.current().select(PasswordHash.class);
    PasswordHash passwordHash = instance.get();
    passwordHash.initialize(new HashMap<>());  // You can pass additional parameters to the initialize() method if needed
    // Check if the provided password is empty
    if (password.isEmpty()) {
        // Password should not be changed
        return;
    }

    // Generate a hashed/salted password entry for the given password
    this.password = passwordHash.generate(password.toCharArray());
}

    /**
     * @return the groupname
     */
    public String getGroupname() {
        return groupname;
    }

    /**
     * @param groupname the groupname to set
     */
    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }
     @Override
    public String toString() {
        return "cst8218.deca0058.appuser.entity.AppUser[ id=" + id + " ]";
    }
}
