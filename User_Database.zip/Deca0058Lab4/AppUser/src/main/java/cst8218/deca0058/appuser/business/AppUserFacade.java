/*Christopher Decarie-Dawson
 *date:2023-07-24
 *Student#:040718315
 *AppUserFacade.java
 *###################################
 * used to link up the entity manager in Abstractfacade and the persistence unit
 * to the super class.
 */
package cst8218.deca0058.appuser.business;

import cst8218.deca0058.appuser.entity.AppUser;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author christopher decarie-dawson
 */
@Stateless
public class AppUserFacade extends AbstractFacade<AppUser> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AppUserFacade() {
        super(AppUser.class);
    }
    
}
